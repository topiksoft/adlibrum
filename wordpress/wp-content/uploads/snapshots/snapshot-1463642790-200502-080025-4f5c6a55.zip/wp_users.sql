CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spam` tinyint NOT NULL DEFAULT '0',
  `deleted` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'admin', '$P$BE6FJ/7Q5n7h5CZy6FXDXt5bt2Avrb/', 'admin', 'soos.gabor@adlibrum.hu', '', '2016-05-06 20:56:11', '', '0', 'Ad Librum Kiadó', '0', '0'); 
INSERT INTO `wp_users` VALUES ('2', 'teodora', '$P$B/qFxOD0Pr0gyCZSS8PWe5bKBwHnJH.', 'teodora', 'salamon.teodora@adlibrum.hu', '', '2016-05-16 22:13:57', '', '0', 'Salamon Teodóra', '0', '0'); 
INSERT INTO `wp_users` VALUES ('3', 'kornel', '$P$BYj9BWUB5QLQ9w3f85gorVrUjtYrM6.', 'kornel', 'korondi.kornel@gmail.com', '', '2016-08-16 07:46:49', '', '0', 'Korondi Kornél', '0', '0'); 
INSERT INTO `wp_users` VALUES ('5', 'kiado', '$P$B.GPsjspfex82Rew9xxBpQRa9eX4bO.', 'kiado', 'kiado@adlibrum.hu', '', '2017-01-11 11:22:58', '1484133780:$P$BmNxMHuBEnc9kPeq9VkOXLi3.r0ObN.', '0', 'Ad Librum Kiadó', '0', '0'); 
INSERT INTO `wp_users` VALUES ('6', 'konyvek', '$P$BClzNiCkG/sUHYDIq3a2lkJh/IffV5.', 'konyvek', 'konyvek@adlibrum.hu', '', '2017-05-31 12:34:36', '', '0', 'Gorove Eszter', '0', '0'); 
INSERT INTO `wp_users` VALUES ('7', 'marketing', '$P$BT69BAJKT68xNImvecJtyAXafpSBiF0', 'marketing', 'marketing@adlibrum.hu', '', '2019-02-08 09:29:39', '', '0', 'Nagy Eszteranna', '0', '0');
# --------------------------------------------------------

