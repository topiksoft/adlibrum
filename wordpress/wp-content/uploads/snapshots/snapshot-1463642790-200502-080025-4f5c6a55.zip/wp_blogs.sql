CREATE TABLE IF NOT EXISTS `wp_blogs` (
  `blog_id` bigint NOT NULL AUTO_INCREMENT,
  `site_id` bigint NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint NOT NULL DEFAULT '1',
  `archived` tinyint NOT NULL DEFAULT '0',
  `mature` tinyint NOT NULL DEFAULT '0',
  `spam` tinyint NOT NULL DEFAULT '0',
  `deleted` tinyint NOT NULL DEFAULT '0',
  `lang_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_blogs`;
 
INSERT INTO `wp_blogs` VALUES ('1', '1', 'www.adlibrum.hu', '/', '2016-05-19 13:17:24', '2016-05-20 05:30:24', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('2', '1', 'villax.adlibrum.hu', '/', '2016-05-20 19:07:43', '2016-05-21 13:19:44', '1', '0', '0', '0', '0', '0');
# --------------------------------------------------------

