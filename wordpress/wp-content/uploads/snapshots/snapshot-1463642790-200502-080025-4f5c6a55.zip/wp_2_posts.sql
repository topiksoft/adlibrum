CREATE TABLE IF NOT EXISTS `wp_2_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_2_posts`;
 
INSERT INTO `wp_2_posts` VALUES ('1', '1', '2016-05-20 17:07:43', '2016-05-20 17:07:43', 'Üdvözlet a(z) <a href="http://www.adlibrum.hu/">Az Ad Librum csoport honlapjai</a> honlapon. Ez az első saját WordPress-bejegyzés. Módosítható, vagy törölhető, aztán megkezdhető a honlap tartalommal történő feltöltése!', 'Helló Világ!', '', 'publish', 'open', 'open', '', 'hello-vilag', '', '', '2016-05-20 17:07:43', '2016-05-20 17:07:43', '', '0', 'http://villax.adlibrum.hu/?p=1', '0', 'post', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('2', '1', '2016-05-20 17:07:43', '2016-05-20 17:07:43', 'Ez egy mintaoldal, egy WordPress-alapú honlap egy oldalának létrehozásához. Az oldal különbözik a bejegyzéstől, mert az oldal állandóan látszik a honlap menüjében, a navigáció során (a legtöbb sablonban). Az emberek többsége használja a Névjegy oldalt, amely arra szolgál, hogy a lehetséges látogatói számára elmondjanak magukról, vállalkozásukról, a honlapról néhány jellemző mondatot. Egyik lehetséges megoldás erre pl.:\n\n<blockquote>Helló Emberek!Ezt a fordítást a WordPress Magyarország Fordítói csapata végezte. Sok száz munkaórát fektettünk abba, hogy ezt a remek tartalomkezelő rendszert anyanyelvünkön, magyarul használhassa mindenki.</blockquote>\n\n.... vagy egy másik példa:\n<blockquote>A<strong> WordPress Magyarország</strong> tulajdonképpen a kezdetektől létezik anélkül, hogy kihirdette volna létét. <strong>A WordPress Magyarország egy Közösség!</strong> - a nyílt forráskódú, zseniális WordPress tartalomkezelő rendszer alkalmazására, megismerésére, tanulására szövetkeztünk.</blockquote>\n\nÚj WordPress-felhasználóként a <a href="http://villax.adlibrum.hu/wp-admin/">Vezérlőpult</a>ba lépve ez az oldal törölhető, módosítható, és új oldalak hozhatóak létre saját tartalommal. Jó szórakozást kíván a WordPress Nemzeközi Közössége!', 'Ez egy minta oldal', '', 'publish', 'closed', 'open', '', 'ez-egy-minta-oldal', '', '', '2016-05-20 17:07:43', '2016-05-20 17:07:43', '', '0', 'http://villax.adlibrum.hu/?page_id=2', '0', 'page', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('3', '1', '2016-05-21 15:18:46', '2016-05-21 13:18:46', 'képpel', 'Villax Richárd', '', 'publish', 'closed', 'closed', '', 'villax-richard', '', '', '2016-05-21 15:18:46', '2016-05-21 13:18:46', '', '0', 'http://villax.adlibrum.hu/?page_id=3', '0', 'page', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('4', '1', '2016-05-21 15:18:46', '2016-05-21 13:18:46', 'képpel', 'Villax Richárd', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2016-05-21 15:18:46', '2016-05-21 13:18:46', '', '3', 'http://villax.adlibrum.hu/3-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('5', '1', '2016-05-21 15:19:11', '2016-05-21 13:19:11', 'borítóképpel', 'Fanyűvők - Nemzeti Jeti', '', 'publish', 'closed', 'closed', '', 'fanyuvok-nemzeti-jeti', '', '', '2016-05-21 15:19:23', '2016-05-21 13:19:23', '', '0', 'http://villax.adlibrum.hu/?page_id=5', '0', 'page', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('6', '1', '2016-05-21 15:19:11', '2016-05-21 13:19:11', '', 'Fanyűvők - Nemzeti Jeti', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-05-21 15:19:11', '2016-05-21 13:19:11', '', '5', 'http://villax.adlibrum.hu/5-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('7', '1', '2016-05-21 15:19:23', '2016-05-21 13:19:23', 'borítóképpel', 'Fanyűvők - Nemzeti Jeti', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-05-21 15:19:23', '2016-05-21 13:19:23', '', '5', 'http://villax.adlibrum.hu/5-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('8', '1', '2016-05-21 15:19:44', '2016-05-21 13:19:44', 'Ad Librum', 'Kiadó', '', 'publish', 'closed', 'closed', '', 'kiado', '', '', '2016-05-21 15:19:44', '2016-05-21 13:19:44', '', '0', 'http://villax.adlibrum.hu/?page_id=8', '0', 'page', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('9', '1', '2016-05-21 15:19:44', '2016-05-21 13:19:44', 'Ad Librum', 'Kiadó', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-21 15:19:44', '2016-05-21 13:19:44', '', '8', 'http://villax.adlibrum.hu/8-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('10', '1', '2016-05-21 15:21:21', '2016-05-21 13:21:21', ' ', '', '', 'publish', 'closed', 'closed', '', '10', '', '', '2016-05-21 15:21:21', '2016-05-21 13:21:21', '', '0', 'http://villax.adlibrum.hu/?p=10', '3', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('11', '1', '2016-05-21 15:21:21', '2016-05-21 13:21:21', '', 'Fanyűvők – Nemzeti Jeti', '', 'publish', 'closed', 'closed', '', 'fanyuvok-nemzeti-jeti', '', '', '2016-05-21 15:21:21', '2016-05-21 13:21:21', '', '0', 'http://villax.adlibrum.hu/?p=11', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_2_posts` VALUES ('12', '1', '2016-05-21 15:21:21', '2016-05-21 13:21:21', ' ', '', '', 'publish', 'closed', 'closed', '', '12', '', '', '2016-05-21 15:21:21', '2016-05-21 13:21:21', '', '0', 'http://villax.adlibrum.hu/?p=12', '2', 'nav_menu_item', '', '0');
# --------------------------------------------------------

