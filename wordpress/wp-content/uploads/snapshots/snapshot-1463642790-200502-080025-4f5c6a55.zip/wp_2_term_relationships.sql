CREATE TABLE IF NOT EXISTS `wp_2_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_2_term_relationships`;
 
INSERT INTO `wp_2_term_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `wp_2_term_relationships` VALUES ('10', '2', '0'); 
INSERT INTO `wp_2_term_relationships` VALUES ('11', '2', '0'); 
INSERT INTO `wp_2_term_relationships` VALUES ('12', '2', '0');
# --------------------------------------------------------

