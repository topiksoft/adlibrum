CREATE TABLE IF NOT EXISTS `wp_registration_log` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blog_id` bigint NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_registration_log`;
 
INSERT INTO `wp_registration_log` VALUES ('1', 'soos.gabor@adlibrum.hu', '78.131.47.231', '2', '2016-05-20 19:07:43');
# --------------------------------------------------------

