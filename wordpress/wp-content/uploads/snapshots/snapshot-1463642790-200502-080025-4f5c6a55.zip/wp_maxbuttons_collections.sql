CREATE TABLE IF NOT EXISTS `wp_maxbuttons_collections` (
  `meta_id` int NOT NULL AUTO_INCREMENT,
  `collection_id` int NOT NULL,
  `collection_key` varchar(255) DEFAULT NULL,
  `collection_value` text,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_maxbuttons_collections`;

# --------------------------------------------------------

