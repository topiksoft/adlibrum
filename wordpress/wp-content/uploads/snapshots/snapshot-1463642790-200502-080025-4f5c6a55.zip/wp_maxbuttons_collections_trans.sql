CREATE TABLE IF NOT EXISTS `wp_maxbuttons_collections_trans` (
  `name` varchar(1000) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `expire` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
TRUNCATE TABLE `wp_maxbuttons_collections_trans`;

# --------------------------------------------------------

