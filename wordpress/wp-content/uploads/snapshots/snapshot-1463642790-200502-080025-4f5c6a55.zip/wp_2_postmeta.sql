CREATE TABLE IF NOT EXISTS `wp_2_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_2_postmeta`;
 
INSERT INTO `wp_2_postmeta` VALUES ('1', '2', '_wp_page_template', 'default'); 
INSERT INTO `wp_2_postmeta` VALUES ('2', '3', '_edit_lock', '1463836587:1'); 
INSERT INTO `wp_2_postmeta` VALUES ('3', '3', '_edit_last', '1'); 
INSERT INTO `wp_2_postmeta` VALUES ('4', '5', '_edit_lock', '1463836628:1'); 
INSERT INTO `wp_2_postmeta` VALUES ('5', '5', '_edit_last', '1'); 
INSERT INTO `wp_2_postmeta` VALUES ('6', '8', '_edit_lock', '1463836646:1'); 
INSERT INTO `wp_2_postmeta` VALUES ('7', '8', '_edit_last', '1'); 
INSERT INTO `wp_2_postmeta` VALUES ('8', '10', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_2_postmeta` VALUES ('9', '10', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_2_postmeta` VALUES ('10', '10', '_menu_item_object_id', '8'); 
INSERT INTO `wp_2_postmeta` VALUES ('11', '10', '_menu_item_object', 'page'); 
INSERT INTO `wp_2_postmeta` VALUES ('12', '10', '_menu_item_target', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('13', '10', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_2_postmeta` VALUES ('14', '10', '_menu_item_xfn', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('15', '10', '_menu_item_url', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('17', '11', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_2_postmeta` VALUES ('18', '11', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_2_postmeta` VALUES ('19', '11', '_menu_item_object_id', '5'); 
INSERT INTO `wp_2_postmeta` VALUES ('20', '11', '_menu_item_object', 'page'); 
INSERT INTO `wp_2_postmeta` VALUES ('21', '11', '_menu_item_target', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('22', '11', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_2_postmeta` VALUES ('23', '11', '_menu_item_xfn', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('24', '11', '_menu_item_url', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('26', '12', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_2_postmeta` VALUES ('27', '12', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_2_postmeta` VALUES ('28', '12', '_menu_item_object_id', '3'); 
INSERT INTO `wp_2_postmeta` VALUES ('29', '12', '_menu_item_object', 'page'); 
INSERT INTO `wp_2_postmeta` VALUES ('30', '12', '_menu_item_target', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('31', '12', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_2_postmeta` VALUES ('32', '12', '_menu_item_xfn', ''); 
INSERT INTO `wp_2_postmeta` VALUES ('33', '12', '_menu_item_url', '');
# --------------------------------------------------------

