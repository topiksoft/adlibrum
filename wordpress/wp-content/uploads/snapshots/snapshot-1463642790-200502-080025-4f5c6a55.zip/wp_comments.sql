CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_comments`;
 
INSERT INTO `wp_comments` VALUES ('4', '638', 'Barczikay Lilla dedikált a könyvhéten - Barczikay Lilla írónő honlapja', '', 'http://barczikaylilla.konyv.guru/barczikay-lilla-dedikalt-konyvheten/', '87.229.108.196', '2016-06-14 11:27:01', '2016-06-14 09:27:01', '[&#8230;] Lilla második könyvét, a Bátyám könnyeit dedikálta az Ünnepi Könyvhéten. A kiadó munkatársai nem hagyták ki az alkalmat, hogy [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.5.2', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('6', '664', 'A Könyvhéten is bemutatta kötetét Zsiros András &#8211; Kisállattenyésztés', '', 'http://kisallattenyesztes.hu/a-konyvheten-bemutatta-kotetet-zsiros-andras/', '87.229.108.196', '2016-06-17 08:14:47', '2016-06-17 06:14:47', '[&#8230;] szólt ugyan, de szakmai szempontból fontos kötettel rukkolt elő Zsiros András, aki a Tarajosvilág &#8211; Hányféleképpen hajthat hasznot a sokszínű baromfiudvar? című szakkönyvét dedikálta múlt vasárnap kora délután a Vörösmarty téren. Az Ad Librum [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.5.2', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('3', '538', 'Megjelent a Fanyűvők - Villax Richárd író honlapja', '', 'http://villax.konyv.guru/megjelent-a-fanyuvok/', '87.229.108.196', '2016-06-06 08:40:09', '2016-06-06 06:40:09', '[&#8230;] Végre kézbe vehető a Fanyűvők, avagy Nemzeti jeti, Villax Richárd hungarogorrorja. A szerző a könyvhéten dedikál. [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.5.2', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('5', '741', 'Cıvata', '', 'http://dunno.dynu.com/civatacilar', '54.171.83.145', '2016-06-14 19:47:14', '2016-06-14 17:47:14', '[&#8230;] http://www.adlibrum.hu/a-konyvhet-negyedik-napja-wanderer-janos-dedikalt/ [&#8230;]', '0', 'spam', 'The Incutio XML-RPC PHP Library', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('7', '1753', '&#8220;Nagyon tanulságos más-más kultúrák ablakain keresztül kinézni a nagyvilágra&#8221; &#8211; Könyv Guru', '', 'http://konyv.guru/nagyon-tanulsagos-mas-mas-kulturak-ablakain-keresztul-kinezni-a-nagyvilagra/', '87.229.108.196', '2016-11-22 07:02:02', '2016-11-22 06:02:02', '[&#8230;] akinek a napokban jelent meg első verseskötete, az Ad Librum kiadó gondozásában publikált Tudatelégtelenség. Az Olaszországban élő költőnő az interjúban beszélt belső otthonteremtésről, a [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.6.1', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('8', '2478', 'Könyvmegjelenés, könyvbemutató és könyvfesztivál &#8211; A Szektor krónikái hivatalos honlapja', '', 'http://szektorkronikai.konyv.guru/konyvmegjelenes-konyvbemutato-es-konyvfesztival/', '87.229.108.196', '2017-04-13 16:05:38', '2017-04-13 15:05:38', '[&#8230;] Hivatalosan is megjelent A Szektor krónikái – Felbukkanás, amiről az Ad Librum Kiadó is hírt adott. [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.7.3', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('9', '2632', '“Sikerült majdnem mindenkit zavarba hozni” – Könyv Guru', '', 'http://konyv.guru/sikerult-majdnem-mindenkit-zavarba-hozni/', '87.229.108.196', '2017-05-30 06:00:29', '2017-05-30 05:00:29', '[&#8230;] Kiadó standjánál, korábbi kötete, A mi &#8217;56-unk pedig ismeretterjesztő kategóriában bejutott az Aranykönyv-szavazáson a TOP10-be. Az interjúban a szerző mesél arról, hogyan egyezteti össze egy tanyán zajló, kisgyermekes [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.7.5', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('10', '2628', '&#8220;Nem szabad elfelejteni, hogy a násznép csak statisztál a mi örömünkhöz&#8221; &#8211; Könyv Guru', '', 'http://konyv.guru/nem-szabad-elfelejteni-hogy-a-nasznep-csak-statisztal-a-mi-oromunkhoz/', '87.229.108.196', '2017-06-06 06:02:31', '2017-06-06 05:02:31', '[&#8230;] Expert Books kiadó gondozásában megjelenő kötet szerzője &#8211; akivel az érdeklődők a könyvheti dedikáláson is találkozhatnak &#8211; a beszélgetés során kitér arra, hogy miért tart a hozzá forduló pároknak [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/4.7.5', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('11', '3491', 'Részlet &#8211; Kóborlásaim az élet ösvényein &#8211; Szem&eacute;lyes T&ouml;rt&eacute;nelem', '', 'http://szemelyestortenelem.hu/reszlet-koborlasaim-az-elet-osvenyein/', '94.199.180.11', '2019-01-03 12:01:31', '2019-01-03 11:01:31', '[&#8230;] Erdei László Kóborlásaim az élet ösvényein című könyvének részletét olvashatják most az Ad Librum oldalán. [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/5.0.2', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('12', '3508', 'Könyvhét az emlékek jegyében &#8211; Szem&eacute;lyes T&ouml;rt&eacute;nelem', '', 'http://szemelyestortenelem.hu/konyvhet-az-emlekek-jegyeben/', '94.199.180.11', '2019-01-03 12:02:39', '2019-01-03 11:02:39', '[&#8230;] Györgyné Marika élménybeszámolója az Ad Librum oldalán a [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/5.0.2', 'pingback', '0', '0'); 
INSERT INTO `wp_comments` VALUES ('13', '3401', 'Részlet Mayer Antal: “Én már választottam hazát…”című könyvéből &#8211; Szem&eacute;lyes T&ouml;rt&eacute;nelem', '', 'http://szemelyestortenelem.hu/reszlet-mayer-antal-en-mar-valasztottam-hazatcimu-konyvebol/', '94.199.180.11', '2019-01-03 12:03:00', '2019-01-03 11:03:00', '[&#8230;] A teljes bejegyzés az Ad Librum kiadó oldalán olvasható. [&#8230;]', '0', '1', 'The Incutio XML-RPC PHP Library -- WordPress/5.0.2', 'pingback', '0', '0');
# --------------------------------------------------------

