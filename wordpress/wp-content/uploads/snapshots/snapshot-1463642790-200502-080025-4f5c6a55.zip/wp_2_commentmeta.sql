CREATE TABLE IF NOT EXISTS `wp_2_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_2_commentmeta`;
 
INSERT INTO `wp_2_commentmeta` VALUES ('1', '1', '_wp_trash_meta_status', '1'); 
INSERT INTO `wp_2_commentmeta` VALUES ('2', '1', '_wp_trash_meta_time', '1463836360');
# --------------------------------------------------------

