CREATE TABLE IF NOT EXISTS `wp_mailerlite_forms` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` tinytext COLLATE utf8_bin,
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `data` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
TRUNCATE TABLE `wp_mailerlite_forms`;
 
INSERT INTO `wp_mailerlite_forms` VALUES ('1', '2016-06-19 09:22:10', 'Ad Librum hírlevél széles', '2', 'a:2:{s:2:"id";s:5:"68467";s:4:"code";s:6:"s1r6b8";}');
# --------------------------------------------------------

