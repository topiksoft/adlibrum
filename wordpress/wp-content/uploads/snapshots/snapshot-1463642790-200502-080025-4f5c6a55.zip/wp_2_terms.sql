CREATE TABLE IF NOT EXISTS `wp_2_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_2_terms`;
 
INSERT INTO `wp_2_terms` VALUES ('1', 'Egyéb', 'egyeb', '0'); 
INSERT INTO `wp_2_terms` VALUES ('2', 'Főmenü', 'fomenu', '0');
# --------------------------------------------------------

